﻿using System.Security.Permissions;
using System.Windows.Forms;

namespace Asteroids
{
    /// <summary>
    /// Класс для перегрузки метода ProcessMnemonic 
    /// </summary>
    public class MyMnemonicButton : Button
    {
        /// <summary>
        /// ss
        /// </summary>
        /// <param name="inputChar"></param>
        /// <returns></returns>
        [UIPermission(SecurityAction.Demand, Window = UIPermissionWindow.AllWindows)]
        protected override bool ProcessMnemonic(char inputChar)
        {

            if (CanSelect && IsMnemonic(inputChar, this.Text))
            {
                MessageBox.Show("You've raised the click event " +
                    "using the mnemonic.");
                this.PerformClick();
                return true;
            }
            return false;
        }

    }
}
