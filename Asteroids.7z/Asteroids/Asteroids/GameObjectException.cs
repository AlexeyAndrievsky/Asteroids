﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asteroids
{
    /// <summary>
    /// Класс исключение для GameObject
    /// </summary>
    class GameObjectException : Exception
    {
        #region .ctor
        public GameObjectException(string message): base(message)
        {

        }
        #endregion
    }
}
